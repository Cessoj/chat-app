import Contact from './components/contact.js';

function App() {
  return (
    <div className="App">
      <Contact/>
      <h1>test</h1>
    </div>
  );
}

export default App;
