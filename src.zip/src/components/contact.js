import React,{ Component } from 'react';
import './contact.css';

class Contact extends Component{
    render(){
        return(
            <div>
                <img src='https://randomuser.me/api/portraits/men/21.jpg'/>
                <div>
                    <h2>Justin Carroll</h2>
                </div>
            </div>
        );
    }
}

export default Contact;